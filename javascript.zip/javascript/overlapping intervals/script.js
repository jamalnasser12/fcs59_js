function merge_intervals(intervals) {
    

 }
// function func(){
//     const input = document.getElementById("intervals").value;
//     let intervals = [];
//     
//             startIndex = i + 1; // The number after the opening bracket
//         } else if(input[i]===']'){
//             endIndex=i-1;
//            
//      ById("result").innerText = "Merged Intervals:" + result;
    
//     }

